import React from 'react';
import IMAGE from '../../../App.images.js';
import { Link } from 'react-router-dom';
import global, {routerMapping } from '../../../global';

const navMenu = [{  
   "title": "IB MB Maintenance",
   "titleId": "IB_MB_MAINTENANCE",
   "seq": 1,
   "menu": [
      {
         "menuDesc": "BOT Metrics",
         "menuId": "BOT_METRICS",
         "seq": 1
      },
      {  
         "menuDesc": "Settings",
         "menuId": "IBMB_SETTINGS",
         "seq": 2,
         "subMenu": [{
               "menuDesc": "System Settings",
               "menuId": "IBMB_SYSTEM_SETTINGS",
               "seq": 1
            },
            {
               "menuDesc": "Charity Settings",
               "menuId": "IBMB_CHARITY_SETTINGS",
               "seq": 2
            },
            {
               "menuDesc": "T & C Settings",
               "menuId": "IBMB_TNC_SETTINGS",
               "seq": 3
            },
            {
               "menuDesc": "Property Settings",
               "menuId": "IBMB_PROPERTY_SETTINGS",
               "seq": 4
            }
         ]
      },
      {
         "menuDesc": "Q & A",
         "menuId": "BOT_QA",
         "seq": 5
      },
      {
         "menuDesc": "Test BOT",
         "menuId": "TEST_BOT",
         "seq": 7
      },
      {
         "menuDesc": "Pinpoint Admin",
         "menuId": "PINPOINT_ADMIN",
         "seq": 8
      }
   ]
}];


function SubMenuList(props) {
  const lists = props.lists;
  const listItems = lists.map((menu) =>
    <li className={"nav-item " + (menu.subMenu && menu.subMenu.length > 0 ? 'nav-dropdown' : '')} key={menu.menuId}>
    	<Link className={"nav-link " + (menu.subMenu && menu.subMenu.length > 0 ? 'nav-dropdown-toggle' : '')} to={`${routerMapping[menu.menuId]}`}>
      		<i className="nav-icon icon-pin"></i>{menu.menuDesc}
    	</Link>    	
    	{menu.subMenu && menu.subMenu.length > 0 &&
        	<SubMenuList lists={menu.subMenu} />
    	}
    </li>
  );
  return (
  	<React.Fragment>
	  	{lists.length > 0 &&
		    <ul className="nav-dropdown-items">
		      {listItems}
		    </ul>
		}
	</React.Fragment>
  );
}


export default function () {
    return (
    	<div className="sidebar">
	        <nav className="sidebar-nav">
		        <ul className="nav">
		        	 <li className="nav-item">
		                <a className="nav-link" href="javascript:void(0);">
		               		<i className="nav-icon icon-speedometer"></i> Dashboard
		               		<span className="badge badge-primary">NEW</span>
		                </a>
		            </li>
		            {navMenu.map((menuItem) =>
				        <li className="nav-item nav-dropdown" key={menuItem.titleId}>
              		<a className="nav-link nav-dropdown-toggle" href="javascript:void(0);">
                		<i className="nav-icon icon-user"></i>{menuItem.title}
                	</a>
                	<SubMenuList lists={menuItem.menu} />
                </li>
				    )}
		        </ul>				        
		    </nav>
		    <button className="sidebar-minimizer brand-minimizer" type="button"></button>
	    </div>
    )
}