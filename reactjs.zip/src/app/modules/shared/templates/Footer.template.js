import React from 'react';
import IMAGE from '../../../App.images.js';

export default function () {
    return (
        <footer className="app-footer">
		   <div>
		      <span>&copy; 2018 </span>
		      <a href="javascript:void(0);">First Abu Dhabi Bank</a>
		   </div>
		   <div className="ml-auto">
		      <a href="javascript:void(0);">FGB is a trademark owned by First Abu Dhabi Bank PJSC</a>
		   </div>
		</footer>
    )
}