import React from 'react'
import IMAGE from '../../../App.images.js';
import RoutesDOM from '../../dashboard/route.js';
import { BrowserRouter, Route, Switch } from 'react-router-dom';

export default function () {
    return (
        <main>
		    <RoutesDOM/>
		</main>
    )
}