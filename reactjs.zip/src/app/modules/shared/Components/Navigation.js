import React from 'react';
import navigationTemplate from '../templates/Navigation.template.js'
import history from '../../../history';

import global, {routerMapping } from '../../../global';


class Navigation extends React.Component {

	handleClick = () => {
	    console.log(routerMapping.ABOUT);
	    history.push('/settings/charitySettings');
	}
	  
	render() {
		return navigationTemplate.call(this)
	}
}

export default Navigation;
