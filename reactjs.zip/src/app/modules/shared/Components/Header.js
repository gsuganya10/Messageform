import React from 'react';
import headerTemplate from '../templates/Header.template.js'


class Header extends React.Component {
  render() {
    return headerTemplate.call(this)
  }
}

export default Header;
