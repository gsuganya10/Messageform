import React from 'react';
import footerTemplate from '../templates/Footer.template.js'


class Footer extends React.Component {
  render() {
    return footerTemplate.call(this)
  }
}

export default Footer;
