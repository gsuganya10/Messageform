import React from 'react';
import baseViewTemplate from '../templates/BaseView.template.js'


class BaseView extends React.Component {
  render() {
    return baseViewTemplate.call(this)
  }
}

export default BaseView;
