import React from 'react';
import IMAGE from '../../../App.images.js';
import HEADER from '../../shared/Components/Header.js';
import FOOTER from '../../shared/Components/Footer.js';
import NAVIGATION from '../../shared/Components/Navigation.js';
import BASEVIEW from '../../shared/Components/BaseView.js';
import { BrowserRouter as Router } from "react-router-dom";

export default function () {
    return (
        <div className="container">
        	{this.renderRedirect()}
		    <div className="row justify-content-center">
		      <div className="col-md-8">
		         <div className="card-group">
		         	<div className="card text-white bg-primary py-5 d-md-down-none">
		               <div className="card-body text-center">
		                  <div>
		                  	<a href="javascript:void(0);">
		                  		<img className="navbar-brand-full" src={IMAGE.logo} width="75"  alt="FGB CI Admin"/>
		                  	</a>
		                     <p style={{ marginTop: 10 }}>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
		                  </div>
		               </div>
		            </div>
		            <div className="card p-4">
		               <div className="card-body">
		                  <h1>Login</h1>
		                  <p className="text-muted">Sign In to your account</p>
		                  <div className="input-group mb-3">
		                     <div className="input-group-prepend">
		                        <span className="input-group-text">
		                        <i className="icon-user"></i>
		                        </span>
		                     </div>
		                     <input className="form-control" type="text" placeholder="Username"/>
		                  </div>
		                  <div className="input-group mb-4">
		                     <div className="input-group-prepend">
		                        <span className="input-group-text">
		                        <i className="icon-lock"></i>
		                        </span>
		                     </div>
		                     <input className="form-control" type="password" placeholder="Password"/>
		                  </div>
		                  <div className="row">
		                     <div className="col-6">
		                        <button className="btn btn-primary px-4" type="button" onClick={this.verifyLogin}>Login</button>
		                     </div>
		                     <div className="col-6 text-right">
		                        <button className="btn btn-link px-0" type="button">Forgot password?</button>
		                     </div>
		                  </div>
		               </div>
		            </div>		            
		         </div>
		      </div>
		   </div>
		</div>
    )
}