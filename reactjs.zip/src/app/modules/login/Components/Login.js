import React from 'react';
import loginTemplate from '../templates/Login.template.js'
import history from '../../../history';
import { Route, Redirect } from 'react-router-dom'

class Login extends React.Component {
	constructor(props) {
        super(props);
        this.state = {toDashboard: false};
    }

    componentWillMount(){
	    document.getElementById('body').className='app flex-row align-items-center'
	}
	
	componentWillUnmount(){
	    document.getElementById('body').className='app'
	}

    verifyLogin = () => {
	   this.setState({toDashboard: true });
	}

	renderRedirect = () => {
	    if (this.state.toDashboard) {
	      return <Redirect to='/dashboard' />
	    }
	}

  	render() {
    	return loginTemplate.call(this)
  	}
}

export default Login;
