import axios from 'axios';
import global, {serviceURL,baseURL } from '../../../global';


export {fetchSystemSettings};

function fetchSystemSettings(data) {
  const url = `${baseURL}${serviceURL.systemSettings}`;
  return axios.post(url,data)
  		.then(response => response.data);
}