import React from 'react';
import botMetricsTemplate from '../templates/BotMetrics.template.js'


class BotMetrics extends React.Component {
  render() {
    return botMetricsTemplate.call(this)
  }
}

export default BotMetrics;
