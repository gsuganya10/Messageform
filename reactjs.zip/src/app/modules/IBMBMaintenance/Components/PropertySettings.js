import React from 'react';
import propertySettingsTemplate from '../templates/PropertySettings.template.js'


class PropertySettings extends React.Component {
  render() {
    return propertySettingsTemplate.call(this)
  }
}

export default PropertySettings;
