import React from 'react';
import charitySettingsTemplate from '../templates/CharitySettings.template.js'


class CharitySettings extends React.Component {
  render() {
    return charitySettingsTemplate.call(this)
  }
}

export default CharitySettings;
