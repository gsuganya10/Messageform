import React from 'react';
import tncSettingsTemplate from '../templates/TncSettings.template.js'


class TncSettings extends React.Component {
  render() {
    return tncSettingsTemplate.call(this)
  }
}

export default TncSettings;
