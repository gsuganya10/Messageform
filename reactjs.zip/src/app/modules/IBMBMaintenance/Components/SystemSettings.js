import React from 'react';
import systemSettingsTemplate from '../templates/SystemSettings.template.js'
import { fetchSystemSettings } from '../services/service.js';

class SystemSettings extends React.Component {
	constructor(props) {
	    super(props)
	    this.state = {request: {cif:'', cin:'', userName:''}, response: ''}
	}

	handleInputChange = (event) => {
		const request = {...this.state.request}
		const target = event.target;
		const value = target.value;
		const name = target.name;
		request[name] = value;
		this.setState({request});
	}

	fetchSystemSettings = () => {		
		fetchSystemSettings(this.state.request)
	    .then((response) => {
	    	this.setState({response});
	    });

	}

  	render() {
    	return systemSettingsTemplate.call(this)
  	}
}

export default SystemSettings;
