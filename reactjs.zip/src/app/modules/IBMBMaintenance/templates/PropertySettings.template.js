import React from 'react';
import IMAGE from '../../../App.images.js';

export default function () {
    return (
        <h1>Property Settings</h1>
    )
}