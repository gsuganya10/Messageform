import React from 'react';
import IMAGE from '../../../App.images.js';

export default function () {
    return (
        <h1>BotMetrics</h1>
    )
}