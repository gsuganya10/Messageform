import React from 'react';
import IMAGE from '../../../App.images.js';



export default function () {

    return (
    	<React.Fragment>
	        <div className="row">
	        	<div className="col-md-12">
				    <div className="card">
				      <div className="card-header">
				         <strong>System Settings</strong>
				      </div>
				      <div className="card-body">
				         	<form action="" method="post">
				            	<div className="form-group row">
					            	<div className="col-md-4">
					                	<label htmlFor="nf-cif">CIF</label>
					                	<input className="form-control" type="text" name="cif" placeholder="Enter CIF.." 
					                	value={this.state.cif} onChange={this.handleInputChange}/>
					                </div>
					                <div className="col-md-4">
					                	<label htmlFor="nf-cin">CIN</label>
					                	<input className="form-control" type="text" name="cin" placeholder="Enter CIN.."
					                	value={this.state.cin} onChange={this.handleInputChange}/>
					                </div>
					                <div className="col-md-4">
					                	<label htmlFor="nf-username">Username</label>
					                	<input className="form-control" type="text" name="userName" placeholder="Enter Username.."
					                	value={this.state.userName} onChange={this.handleInputChange}/>
					                </div>
				            	</div>
				         	</form>
				      	</div>
				      	<div className="card-footer txt-align-right">
				         	<button className="btn btn-sm btn-primary" type="button" onClick={this.fetchSystemSettings}>
				         		<i className="fa fa-dot-circle-o"></i>Submit
				         	</button>
				         	<button className="btn btn-sm btn-danger mr-lt-7" type="reset">
				         		<i className="fa fa-ban"></i> Reset
				         	</button>
				      	</div>
				    </div>
			    </div>
			</div>
			{this.state.response.channelInfoList && this.state.response.channelInfoList.length > 0 &&
			<div className="row">
				<div className="col">
					<div className="card">
						<div className="card-header">
						   search Results
						</div>
						<div className="card-body">
							<div className="row">
								<div className="col-6 col-lg-3">
								   <div className="card">
								      <div className="card-body p-0 d-flex align-items-center">
								         <i className="fa fa-laptop bg-info p-4 px-5 font-2xl mr-3"></i>
								         <div>
								            <div className="text-value-sm text-info">{this.state.response.cif}</div>
								            <div className="text-muted text-uppercase font-weight-bold small">CIF</div>
								         </div>
								      </div>
								   </div>
								</div>
								<div className="col-6 col-lg-3">
								   <div className="card">
								      <div className="card-body p-0 d-flex align-items-center">
								         <i className="fa fa-laptop bg-info p-4 px-5 font-2xl mr-3"></i>
								         <div>
								            <div className="text-value-sm text-info">{this.state.response.cin}</div>
								            <div className="text-muted text-uppercase font-weight-bold small">CIN</div>
								         </div>
								      </div>
								   </div>
								</div>
							</div>
							<ul className="nav nav-tabs" id="myTab1" role="tablist">
								{this.state.response.channelInfoList.map((channelInfo, index) => (
									<li className="nav-item">
									  <a className={"nav-link " + (index == 0 ? 'active' : '')} id={`channelInfo-tab-${index}`} data-toggle="tab" href={`#channelInfo-${index}`} role="tab" aria-controls={`channelInfo-${index}`} aria-selected={(index == 0 ? true : false)} key={index}>
									  	{channelInfo.channelName}
									  </a>
								    </li>
								))}
							</ul>
							<div className="tab-content" id="myTab1Content">
								{this.state.response.channelInfoList.map((channelInfo, index) => (
								   <div className={"tab-pane fade " + (index == 0 ? 'show active' : '')} id={`channelInfo-${index}`} role="tabpanel" aria-labelledby={`channelInfo-tab-${index}`}>
								   		<div className="row">
										   <div className="col-lg-6">
										      <div className="card">
										         <div className="card-header">
										            Channel Details
										         </div>
										         <div className="card-body">
										            <table className="table table-responsive-sm">
										               <tbody>
										                  	<tr>
																<td>User Name</td>
																<td>{channelInfo.userName}</td>
															</tr>
															<tr>
																<td>Last Success Login</td>
																<td>{channelInfo.lastSuccessfullLogin}</td>
															</tr>
															<tr>
																<td>Last Failure Login</td>
																<td>{channelInfo.lastFailedLogin}</td>
															</tr>
															<tr>
																<td>Login Time</td>
																<td>{channelInfo.lastLoggedIn}</td>
															</tr>
															<tr>
																<td>Last Password Reset Date</td>
																<td>{channelInfo.lastPwdResetDate}</td>
															</tr>
															<tr>
																<td>Last Profile update by Bank</td>
																<td>{channelInfo.lastProfileUpdateByBank}</td>
															</tr>
															<tr>
																<td>Device Id</td>
																<td>{channelInfo.deviceId}</td>
															</tr>
															<tr>
																<td>Locked</td>
																<td>
																	{channelInfo.locked == 'Y' ? (
																        <span class="badge badge-danger">Banned</span>
																    ) : (
																        <span class="badge badge-success">Active</span>
																    )}
																</td>
															</tr>
															<tr>
																<td>Blocked</td>
																<td>
																	{channelInfo.blocked == 'Y' ? (
																        <span class="badge badge-danger">Banned</span>
																    ) : (
																        <span class="badge badge-success">Active</span>
																    )}
																</td>
															</tr>
															<tr>
																<td>Actions</td>
																<td></td>
															</tr>

										               </tbody>
										            </table>
										         </div>
										      </div>
										   </div>
										</div>
								   </div>
								))}	
							</div>
						</div>
					</div>
				</div>
			</div>
			}
		</React.Fragment>
    )
}