import React from 'react';
import { Router, Route, Switch } from 'react-router-dom';
import history from '../../history';
import PropertySettings from './Components/PropertySettings.js';
import SystemSettings from './Components/SystemSettings.js';
import TncSettings from './Components/TncSettings.js';
import CharitySettings from './Components/CharitySettings.js';
import BotMetrics from './Components/BotMetrics.js';

const IBMBMaintenance_Routes = (pros) =>{ 
	return (
		<React.Fragment>
			<Route path='/botMetrics' name="Bot Metrics" component={BotMetrics}/>
			<Route path='/settings/propertySettings' name="Property Settings" component={PropertySettings}/>
		  	<Route path='/settings/systemSettings' name="System Settings" component={SystemSettings}/>
		  	<Route path='/settings/tncSettings' name="T & C Settings" component={TncSettings}/>
		  	<Route path='/settings/charitySettings' name="Charity Settings" component={CharitySettings}/>
	  	</React.Fragment>
	)
}
export default IBMBMaintenance_Routes;