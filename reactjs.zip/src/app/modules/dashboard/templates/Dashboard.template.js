import React from 'react';
import IMAGE from '../../../App.images.js';
import HEADER from '../../shared/Components/Header.js';
import FOOTER from '../../shared/Components/Footer.js';
import NAVIGATION from '../../shared/Components/Navigation.js';
import BASEVIEW from '../../shared/Components/BaseView.js';
import { BrowserRouter as Router } from "react-router-dom";

export default function () {
    return (
	    <div className="app header-fixed sidebar-fixed aside-menu-fixed sidebar-lg-show">
	        <HEADER />
	        <Router>
		        <div className="app-body">
		   			<NAVIGATION />
		   			<main className="main">
				      <ol className="breadcrumb">
				         <li className="breadcrumb-item">Home</li>
				         <li className="breadcrumb-item">
				            <a href="javascript:void(0);">Admin</a>
				         </li>
				         <li className="breadcrumb-item active">Dashboard</li>
				      </ol>
				      <div className="container-fluid">
				         <div className="animated fadeIn">
				            <BASEVIEW />
				         </div>
				      </div>
				   </main>
		   		</div>
	   		</Router>
	        <FOOTER />
        </div>
    )
}