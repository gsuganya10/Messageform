import React from 'react';
import { BrowserRouter, Router, Route, Switch } from 'react-router-dom';
import Home from './Components/Home.js';
import About from './Components/About.js';
import IBMBMaintenance_Routes from '../IBMBMaintenance/route.js';
import history from '../../history';

const RoutesDOM = (pros) =>{ 
	return (    	
		  	<Switch>
		      <Route exact path='/' component={Home}/>
		      <IBMBMaintenance_Routes />
		    </Switch>
	)
}
export default RoutesDOM;