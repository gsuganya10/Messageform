import React from 'react';
import dashboardTemplate from '../templates/Dashboard.template.js'

class Dashboard extends React.Component {
	constructor(props) {
        super(props)
        this.state = {
            text: "Hello world vignesh"
        }
    }

    componentWillMount(){
	    document.getElementById('body').className='app header-fixed sidebar-fixed aside-menu-fixed sidebar-lg-show'
	}
	
	componentWillUnmount(){
	    document.getElementById('body').className='app'
	}

	render() {
	    return dashboardTemplate.call(this)
	}
}

export default Dashboard;
