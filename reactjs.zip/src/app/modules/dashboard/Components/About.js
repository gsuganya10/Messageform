import React from 'react'

const About = () => (
  <div>
    <h1>Welcome to the About!</h1>
  </div>
)

export default About
