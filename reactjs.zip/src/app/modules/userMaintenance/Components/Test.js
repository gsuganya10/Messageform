import React from 'react'

const Test = () => (
  <div>
    <h1>Welcome to the Tornadoes Website test!</h1>
  </div>
)

export default Test
