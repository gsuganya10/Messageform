import React from 'react';
import appTemplate from './App.template.js';

class App extends React.Component {
	constructor(props) {
        super(props)
        this.state = {
            text: "Hello world vignesh"
        }
    }
  render() {
    return appTemplate.call(this)
  }
}

export default App;
