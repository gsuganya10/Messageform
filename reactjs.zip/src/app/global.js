

const routerMapping = {
	ABOUT : "/about",
	BOT_METRICS :"/botMetrics",
	IBMB_PROPERTY_SETTINGS :"/settings/propertySettings",
	IBMB_SYSTEM_SETTINGS :"/settings/systemSettings",
	IBMB_TNC_SETTINGS :"/settings/tncSettings",
	IBMB_CHARITY_SETTINGS :"/settings/charitySettings"
}

const configuration = {
	ABOUT : "/about"
}

const baseURL =  "http://172.20.37.181:8880/PBAdminAPI/resource"

const serviceURL = {
	systemSettings : "/user/fetch"
}

export default global;
export {routerMapping, configuration,serviceURL,baseURL};