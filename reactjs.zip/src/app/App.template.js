import React from 'react';
import IMAGE from './App.images.js';
import { Router, Route, Switch } from 'react-router-dom';
import DASHBOARD from './modules/dashboard/Components/Dashboard.js';
import LOGIN from './modules/login/Components/Login.js';
import history from './history';

export default function () {
    return (    	
    	<Router history={history}>
	    	<Switch>	          
	          	<Route  path="/login" name="login" component={LOGIN} />
	          	<Route exact path="/" name="dashboard" component={DASHBOARD} />
	        </Switch>
        </Router>        
    )
}