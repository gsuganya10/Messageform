import logo from './assets/images/fab.png';
import avatar from './assets/images/avatar.png';

export default {
  logo,
  avatar
}