import $ from 'jquery';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'font-awesome/css/font-awesome.min.css';
import '@coreui/coreui/dist/css/coreui.min.css';
import '@coreui/icons/css/coreui-icons.min.css';
import 'simple-line-icons/css/simple-line-icons.css';
import Popper from 'popper.js';
import 'bootstrap/dist/js/bootstrap.min.js';
import 'perfect-scrollbar/dist/perfect-scrollbar.min.js';
import '@coreui/coreui/dist/js/coreui.min.js';
import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './app/App';
import registerServiceWorker from './registerServiceWorker';

ReactDOM.render(<App /> , document.getElementById('root'));
registerServiceWorker();